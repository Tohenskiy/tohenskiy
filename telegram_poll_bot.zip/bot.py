import os
from aiogram import Bot, Dispatcher, types
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils import executor
from aiogram.dispatcher.filters import CommandStart
import logging

API_TOKEN = os.getenv("API_TOKEN")

logging.basicConfig(level=logging.INFO)
bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

# Настройки опроса
poll_options = {
    "🍕 Пицца": {"limit": 3, "voters": set()},
    "🍔 Бургер": {"limit": 2, "voters": set()},
    "🥗 Салат": {"limit": 1, "voters": set()},
}

# Генерация клавиатуры
def get_keyboard():
    keyboard = InlineKeyboardMarkup()
    for option, data in poll_options.items():
        remaining = data["limit"] - len(data["voters"])
        if remaining > 0:
            btn = InlineKeyboardButton(
                text=f"{option} ({remaining} мест)",
                callback_data=option
            )
            keyboard.add(btn)
    return keyboard

@dp.message_handler(CommandStart())
async def send_poll(message: types.Message):
    await message.answer(
        "🍽 Выберите вариант (ограниченное количество мест):",
        reply_markup=get_keyboard()
    )

@dp.callback_query_handler(lambda c: c.data in poll_options)
async def handle_vote(callback_query: types.CallbackQuery):
    user_id = callback_query.from_user.id
    option = callback_query.data
    voters = poll_options[option]["voters"]
    limit = poll_options[option]["limit"]

    for opt in poll_options:
        if user_id in poll_options[opt]["voters"]:
            await callback_query.answer("❗ Вы уже голосовали", show_alert=True)
            return

    if len(voters) >= limit:
        await callback_query.answer("❌ Этот вариант уже заполнен", show_alert=True)
        return

    voters.add(user_id)
    await callback_query.answer(f"✅ Вы выбрали: {option}")
    await bot.edit_message_reply_markup(
        chat_id=callback_query.message.chat.id,
        message_id=callback_query.message.message_id,
        reply_markup=get_keyboard()
    )

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
